# Financial Chatbot Prototype

## Project
A simple rule-based financial chatbot using pandas and financial data from the 2023-2025 10-K analysis.

## Companies
- Microsoft
- Tesla
- Apple

## What it can answer
The chatbot can answer basic questions about:
- Total revenue
- Net income
- Operating cash flow
- Total assets
- Total liabilities
- Revenue growth

It also keeps track of the company mentioned in the previous message, so a follow-up question can use the same company.

## How to run

Keep `financial_chatbot.py` and `financial_data.csv` in the same folder.

Run:

```bash
python financial_chatbot.py
```

Then try:

- What was Microsoft's revenue in 2025?
- What was its net income in 2024?
- What about operating cash flow?
- What was Tesla's revenue in 2025?
- How has Apple's revenue changed?
- help
- exit

## Limitations

This is a basic prototype. It only handles predefined types of questions and does not use an LLM or advanced NLP. It also uses the static 2023-2025 dataset prepared for this project, so it does not provide real-time financial information.

## Note on financial figures

Figures are in USD millions. Tesla's "Net Income" uses the consolidated net income figure reported in its statements, including noncontrolling interests.
