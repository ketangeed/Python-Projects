import pandas as pd

# Load the financial data
df = pd.read_csv("financial_data.csv")


def get_company_data(company):
    company = company.title()

    if company in df["Company"].unique():
        return df[df["Company"] == company].sort_values("Year")
    else:
        return None


def simple_chatbot(user_query, current_company=None):
    query = user_query.lower().strip()

    # Basic conversation state
    companies = ["microsoft", "tesla", "apple"]

    for company in companies:
        if company in query:
            current_company = company.title()

    if query in ["hi", "hello", "hey"]:
        return "Hi! I can help with basic financial information for Microsoft, Tesla and Apple.", current_company

    if "help" in query:
        return (
            "You can ask about revenue, net income, assets, liabilities, "
            "operating cash flow, or revenue growth. Example: "
            "'What was Tesla revenue in 2025?'",
            current_company
        )

    if current_company is None:
        return (
            "Please mention a company first: Microsoft, Tesla or Apple.",
            current_company
        )

    company_data = get_company_data(current_company)

    # Specific year questions
    year = None
    for y in [2023, 2024, 2025]:
        if str(y) in query:
            year = y
            break

    if "revenue" in query:
        if year:
            value = company_data.loc[
                company_data["Year"] == year, "Total Revenue"
            ].iloc[0]
            return (
                f"{current_company}'s total revenue in {year} was "
                f"${value:,.0f} million.",
                current_company
            )

        first = company_data.iloc[0]["Total Revenue"]
        last = company_data.iloc[-1]["Total Revenue"]
        change = (last - first) / first * 100
        direction = "increased" if change >= 0 else "decreased"

        return (
            f"{current_company}'s revenue {direction} by "
            f"{abs(change):.2f}% from 2023 to 2025.",
            current_company
        )

    if "net income" in query or "profit" in query:
        if year:
            value = company_data.loc[
                company_data["Year"] == year, "Net Income"
            ].iloc[0]
            return (
                f"{current_company}'s net income in {year} was "
                f"${value:,.0f} million.",
                current_company
            )

        first = company_data.iloc[0]["Net Income"]
        last = company_data.iloc[-1]["Net Income"]
        change = (last - first) / first * 100
        direction = "increased" if change >= 0 else "decreased"

        return (
            f"{current_company}'s net income {direction} by "
            f"{abs(change):.2f}% from 2023 to 2025.",
            current_company
        )

    if "operating cash flow" in query or "cash flow" in query:
        if year:
            value = company_data.loc[
                company_data["Year"] == year, "Operating Cash Flow"
            ].iloc[0]
            return (
                f"{current_company}'s operating cash flow in {year} was "
                f"${value:,.0f} million.",
                current_company
            )

        value = company_data.iloc[-1]["Operating Cash Flow"]
        return (
            f"{current_company}'s operating cash flow in 2025 was "
            f"${value:,.0f} million.",
            current_company
        )

    if "assets" in query:
        if year:
            value = company_data.loc[
                company_data["Year"] == year, "Total Assets"
            ].iloc[0]
            return (
                f"{current_company}'s total assets in {year} were "
                f"${value:,.0f} million.",
                current_company
            )

    if "liabilities" in query:
        if year:
            value = company_data.loc[
                company_data["Year"] == year, "Total Liabilities"
            ].iloc[0]
            return (
                f"{current_company}'s total liabilities in {year} were "
                f"${value:,.0f} million.",
                current_company
            )

    if "growth" in query and "revenue" in query:
        first = company_data.iloc[0]["Total Revenue"]
        last = company_data.iloc[-1]["Total Revenue"]
        growth = (last - first) / first * 100
        return (
            f"Revenue growth from 2023 to 2025 was {growth:.2f}% "
            f"for {current_company}.",
            current_company
        )

    return (
        "Sorry, I don't understand that question yet. "
        "Try asking about revenue, net income, assets, liabilities, "
        "or operating cash flow.",
        current_company
    )


def run_chatbot():
    print("Financial Chatbot")
    print("Type 'help' to see example questions or 'exit' to stop.")
    print()

    current_company = None

    while True:
        user_query = input("You: ")

        if user_query.lower().strip() == "exit":
            print("Bot: Thanks for using the financial chatbot.")
            break

        response, current_company = simple_chatbot(
            user_query, current_company
        )

        print("Bot:", response)


if __name__ == "__main__":
    run_chatbot()
